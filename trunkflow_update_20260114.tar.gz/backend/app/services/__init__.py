from app.services.asterisk import AsteriskService
from app.services.ami import AMIClient, get_extensions_status, check_extension_online
